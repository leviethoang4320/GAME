package TowerDefense;

import javax.swing.*;
import java.awt.*;

public class Enemy extends JPanel {
    public Image image,image1,image2;
    public Enemy(){
        ImageIcon imageIcon = new ImageIcon("image/tank2.png");
        image = imageIcon.getImage();
        ImageIcon imageIcon1 = new ImageIcon("image/tank3.png");
        image1 = imageIcon1.getImage();
        ImageIcon imageIcon2 = new ImageIcon("image/tank4.png");
        image2 = imageIcon2.getImage();
    }

    private int x = 0, y=85,hp=30;

    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public void paint(Graphics g)
    {
        g.setColor(Color.RED);
        g.fillRect(x,y-5,hp,3);
        if(y == 85 && x < 855||y>=495)
            g.drawImage(image,x,y,this);
        else if (y==235&&x>295||x<=295&&y>=335&&x>115&&y<495)
            g.drawImage(image2,x,y,this);
        else if(y<235||x<=295&&y>=235&&y<335||x<=115&&y>=335&&y<495)
            g.drawImage(image1,x,y,this);
    }



    public boolean X1(){
        if( y == 85 && x < 855) return true;
        else return false;
    }
    public boolean Y1(){
        if(y<235)
            return true;
        return false;
    }
    public boolean X2(){
        if(y==235&&x>295)
            return true;
        return false;
    }
    public boolean Y2(){
        if(x<=295&&y>=235&&y<335)
            return true;
        return false;
    }
    public boolean X3(){
        if(x<=295&&y>=335&&x>115&&y<495)
            return true;
        return false;
    }
    public boolean Y3(){
        if(x<=115&&y>=335&&y<495)
            return true;
        return false;
    }
    public boolean X4(){
        if(y>=495)
            return true;
        return false;
    }
    public void upX(){
        x+=3;
    }
    public void downX(){
        x-=3;
    }
    public void upY(){
        y+=3;

    }
    public void move(){
        if (X1()) {
            upX();
        } else if (Y1()) upY();
        else if (X2()) downX();
        else if (Y2()) upY();
        else if (X3()) downX();
        else if (Y3()) upY();
        else if (X4()) upX();
    }
}
